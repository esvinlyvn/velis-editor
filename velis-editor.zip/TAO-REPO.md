# Tạo repo velis-editor từ edit-bds

Claude Code làm các bước dưới trong **phiên mở trên repo mới `esvinlyvn/velis-editor`**. Lúc này repo đó chỉ có file `velis-editor.zip` do người dùng upload.

## 0. Chuẩn bị

```
mkdir -p work && printf "work/\nbuild/\n.env\n.secrets/\nnode_modules/\n" > .gitignore
unzip -o velis-editor.zip -d work/pkg && git rm -q velis-editor.zip
git remote add src https://github.com/esvinlyvn/edit-bds.git
git fetch src claude/lucid-cray-hwgt06
SRC=$(git rev-parse --short src/claude/lucid-cray-hwgt06)
```

Nếu `git fetch` báo không có quyền: dừng lại, báo người dùng cấp cho Claude quyền đọc repo `edit-bds` (GitHub → Settings → Applications → Claude → Repository access), rồi làm lại.

## 1. Lấy phần BĐS và lõi dựng

Lấy file theo trạng thái mới nhất của nhánh nguồn. Repo mới bắt đầu lịch sử từ đây; commit đầu tiên ghi mã nguồn `$SRC`.

```
git checkout src/claude/lucid-cray-hwgt06 -- \
  package.json package-lock.json .gitattributes \
  TOOLKIT.md MAP.md TALKING-HEAD.md docs/HAU-KY.md docs/DAC-TA-CHU.md \
  scripts sfx text-presets projects/example
git checkout src/claude/lucid-cray-hwgt06 -- brand/VIS-SHOTS.md brand/shots
git mv brand/VIS-SHOTS.md docs/SHOTS.md && git mv brand/shots docs/shots && rmdir brand 2>/dev/null
```

**Các dự án:** lấy `projects/{casa-villa-kim-tham, huy-tran-casa-villa, qq-casa-villa, tu-casa-villa, palm-river, imperia-sensa-park}`. Với `projects/vanh-dai-2`, mở ra xem trước:
- Dựng từ clip quay thật (có `scripts/asr`, video nguồn của người nói) → lấy về.
- Dựng từ voice TTS hoặc hình Vis → để lại ở edit-bds.

**Bỏ phần của Vis:**
```
git rm -rq --ignore-unmatch scripts/tts scripts/publish text-presets/QUY-TAC-CHON-CHU-VIS.md
printf '{ "videos": [] }\n' > text-presets/history.json
```

## 2. Chép bộ quy tắc

Chép từ `work/pkg/` vào gốc repo, ghi đè nếu trùng tên:
- `CLAUDE.md`, `README.md`
- `docs/VAN-HANH.md`, `docs/TRINH-BAY.md`, `docs/SOURCES.md`
- `.claude/skills/velis-editor/`
- `clients/_mau/brand.json`, `luts/README.md`
- `scripts/hook-pick.mjs`
- `text-presets/QUY-TAC-CHU.md`, `text-presets/pick-text.mjs`

Tạo `clients/<khach>/brand.json` cho các khách đã làm (Quỳnh Quỳnh, Tú, Tú Phan, Huy Trần, Kim Thắm…), lấy từ bảng 4c của `TALKING-HEAD.md`.

## 3. Sửa tham chiếu

- `TALKING-HEAD.md` mục 6: SHOTBOOK viết theo `docs/VAN-HANH.md` mục 3 và phương pháp `docs/SHOTS.md`. Đường dẫn `brand/…` đổi thành `docs/…`.
- `TOOLKIT.md`, `docs/SHOTS.md`, các file trong `text-presets/`: đổi `brand/VIS-SHOTS.md` → `docs/SHOTS.md`, `brand/shots` → `docs/shots`. Bỏ các đoạn chỉ nói về Vis (Gemini TTS, kênh Vis, VIS-STYLE).
- Rà sót: `grep -rniE "vis-style|vis giữ xe|gemini|vis-tts|brand/" --include=*.md --include=*.mjs --include=*.cjs .`. Chỉ được còn phần lịch sử trong `TALKING-HEAD.md` mục 4c.
- `package.json`: đổi `name` thành `velis-editor`, bỏ các script `tts`, `publish`, `vis-*`.

## 4. Kiểm

```
npm install
npm run example                                              # phải render được
node projects/casa-villa-kim-tham/build.mjs --no-render
cd build/casa-villa-kim-tham && npx hyperframes lint && cd -   # 0 error
node scripts/qa/kt-check.cjs build/casa-villa-kim-tham/index.html <composition-id>   # 100%
node text-presets/pick-text.mjs <một text-plan.json mẫu với "mode": "bds">
```

## 5. Commit

```
git add -A && git commit -m "Khởi tạo velis-editor từ edit-bds@$SRC: bộ edit video BĐS từ clip quay thật" && git push -u origin HEAD:main
rm -rf work/pkg
```

Báo người dùng:
- số file đã lấy;
- quyết định với `vanh-dai-2`;
- kết quả các bước kiểm.

Sau đó nhắc người dùng làm phần dọn repo Vis theo `work/pkg/VIS-DON-DEP.md`. Gửi nội dung file đó trong chat, vì `work/` sẽ bị xóa.
