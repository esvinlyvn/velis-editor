# Dọn repo edit-bds sau khi đã có velis-editor

Claude Code làm các bước dưới trong phiên mở trên repo `edit-bds`, nhánh `claude/lucid-cray-hwgt06`. **Chỉ gỡ, không sửa lõi.**

1. Xóa các dự án BĐS đã chuyển sang velis-editor: `projects/{casa-villa-kim-tham, huy-tran-casa-villa, qq-casa-villa, tu-casa-villa, palm-river, imperia-sensa-park}`. Với `vanh-dai-2`: chỉ xóa nếu đã chuyển sang velis-editor.
2. Xóa `TALKING-HEAD.md`, `docs/HAU-KY.md`, `docs/DAC-TA-CHU.md`. **Trước khi xóa:** grep tên từng file; file nào của Vis còn dẫn tới thì sửa tham chiếu trước.
3. Giữ `scripts/asr/`, `scripts/fx/`, `scripts/bg-sample.py`, `scripts/text-contrast.mjs`, vì lõi chữ (`contrastPlan`, `kt-check`) có thể dùng. Chỉ gỡ khi grep chắc chắn không còn ai gọi.
4. Xóa các file `INSTALL-*.md` ở gốc repo.
5. `CLAUDE.md`: bỏ dòng về clip quay thật, thêm dòng: "Edit video BĐS từ clip quay thật nằm ở repo `velis-editor`." Thêm luật `core:`: sửa lõi (`scripts/`, `sfx/`, `text-presets/`) thì commit riêng, message bắt đầu bằng `core:`.
6. Build lại video Vis mới nhất với `--no-render`; lint phải 0 error.
7. Commit "Vis: gỡ phần edit BĐS (đã chuyển sang repo velis-editor)" rồi push.
